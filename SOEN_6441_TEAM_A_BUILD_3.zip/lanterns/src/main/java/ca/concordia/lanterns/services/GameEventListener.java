package ca.concordia.lanterns.services;

/**
 * Created by Ruixiang on 7/25/2015.
 */
public interface GameEventListener {
    void displayEventMessage(String eventMessage);
}
